#install grpc
npm install grpc-tools --save-dev
npm install google-protobuf --save
npm install grpc --save

#install ali oss
npm install ali-oss