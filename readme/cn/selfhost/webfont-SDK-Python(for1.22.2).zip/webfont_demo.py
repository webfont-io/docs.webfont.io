#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from webfont_client.webfont_client import getFontFace

def run():
    webFontFace = getFontFace(
        {'accessKey': 'd9ffb195f7e041d4a03fb8084f9c4fe5', 'content': '中文字体测试', 'tag': '#id1', 'url': ''})
    print('webFontInfo: ' + str(webFontFace))

run()
